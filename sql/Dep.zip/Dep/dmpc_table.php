<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<!-- Sidebar -->
<div class="w3-sidebar w3-light-grey w3-bar-block" style="width:25%">
  <h3 class="w3-bar-item">Categories</h3>
  <!--<a href='com_details.php?id=".$record['Comp_id']."'>".$record['Comp_id']."</a>".-->
  <a href="dudmpc_table.php?id=Ragging" class="w3-bar-item w3-button">Ragging</a>
  <a href="dudmpc_table.php?id=Attendence" class="w3-bar-item w3-button">Attendence</a>
  <a href="dudmpc_table.php?id=Teachers" class="w3-bar-item w3-button">Teachers</a>
  <a href="dudmpc_table.php?id=Canteen" class="w3-bar-item w3-button">Canteen</a>
  <a href="dudmpc_table.php?id=Course" class="w3-bar-item w3-button">Course</a>
  <a href="dudmpc_table.php?id=Exam" class="w3-bar-item w3-button">Exam</a>
  <a href="dudmpc_table.php?id=Others" class="w3-bar-item w3-button">Others</a>
  <a href="Approve_table.php" class="w3-bar-item w3-button">All Approved Complaints</a>

</div>

<!-- Page Content -->
<div style="margin-left:25%">
<div class="w3-container w3-teal">
  <h1>DMPC view</h1>
</div>
      
<div class="abc">
	<p>
	</p>
</div>
</body>
</html>