<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Complaint Category</title>
  <link href='https://fonts.googleapis.com/css?family=Montserrat:700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="style.css">

  
</head>

<body background="workspace_background-wallpaper-1366x768.jpg">

<h1 style="color: #0080FF">Please Let Us Know Who You Are !!</h1>
	<br>
	<a href="#" class="button">Technician</a> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="#" class="button gray" class="gray" formaction="civil.php">Student</a> 
  <script src='http://cdnjs.cloudflare.com/ajax/libs/snap.svg/0.3.0/snap.svg-min.js'></script>
  <br>

    <script  src="js/index.js"></script>

  		



</body>

</html>