<!DOCTYPE html>
<html>
<head>
	<title>Technician or Student</title>
	<header>
		<h1 style="text-align: center; color: white">C H O O S E&nbsp;&nbsp;&nbsp; Y O U R&nbsp;&nbsp;&nbsp;  I D E N T I T Y</h1>
	</header>
	<style type="text/css">
		body{
		      background-image: url("mohammad-alizade-631039-unsplash.jpg");
		      background-size: 100%;
	    }
		 header{
			background-color: black;
			padding: 50px;
			margin: 0px;
			font-family: Tw Cen MT;
			filter: opacity(80%);
		}
		.tech{
			margin-top: 120px;
			background-color: black;
			padding: 10px;
			margin-right: 600px;
			border-radius: 0px 0px 250px;
			filter: opacity(70%);
		}
		.tech:hover,.stud:hover{
			box-shadow: 3px 10px 20px 5px rgba(0, 0, 0, .9);
		}
		.stud{
			margin-top: 60px;
			background-color:/* #662b4c*/ black;
			padding: 10px;
			margin-left: 600px;
			border-radius: 150px 0px 0px;
			filter: opacity(70%);	
		}
	</style>
</head>
<body>
	<a href="login_temp.php" style="text-decoration: none">
		<div class="tech">
			<p style="color: white; font-size: 30px; padding: 0px; font-family:alpaca scarlett demo;margin-left: 150px;" >Technician</p>
		</div>
	</a>
	<a href="studentDetails.php" style="text-decoration: none">
		<div class="stud" >
			<p style="color: white; font-size: 30px; padding: 0px;font-family:alpaca scarlett demo; margin-left: 150px;">Student</p>
		</div>
	</a>
</body>
</html>